import Bot
#078b30c2bb2bfce0bdafb4a03ac8bb48 не меняй так как все по пизде пойдет потому что это ключ api парсера
bot = Bot.WeatherBot("1846811807:AAGZ1Mxq1jlWnLxMbedLiOud451H1ylTr2o", '078b30c2bb2bfce0bdafb4a03ac8bb48')
bot.run()
